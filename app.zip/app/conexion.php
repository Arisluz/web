<?php
$servidor = "localhost";
$usuario = "root"; 
$contraseña = ""; 
$db = "bd_sis_biblioteca";

$conexion = new mysqli($servidor, $usuario, $contraseña, $db);

if ($conexion->connect_errno) {
    die("Conexión Fallida: " . $conexion->connect_error);
}

function obtenerAutores($conexion) {
    $query = "SELECT * FROM autores";
    $resultado = $conexion->query($query);

    if ($resultado) {
        $autores = [];
        while ($fila = $resultado->fetch_assoc()) {
            $autores[] = $fila;
        }
        return $autores;
    } else {
        return [];
    }
}
?>



