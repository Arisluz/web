<?php 
$URL = "http://localhost/www.sis-biblioteca";
include 'app/conexion.php';
echo $URL;

?>


<head>
  <meta charset="utf-8">
  <title>Biblioteca Itla</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Your page description here" />
  <meta name="author" content="" />

  <!-- css -->
  <link href="https://fonts.googleapis.com/css?family=Handlee|Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/bootstrap.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/bootstrap-responsive.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>(app/templeates/Eterna/css/flexslider.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/prettyPhoto.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/camera.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/jquery.bxslider.css" rel="stylesheet" />
  <link href="<?php echo $URL;?>/app/templeates/Eterna/css/style.css" rel="stylesheet" />

  <!-- Theme skin -->
  <link href="color/default.css" rel="stylesheet" />

<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $URL;?>/app/templeates/Eterna/ico/apple-touch-icon-144-precomposed.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $URL;?>/app/templeates/Eterna/ico/apple-touch-icon-114-precomposed.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $URL;?>/app/templeates/Eterna/ico/apple-touch-icon-72-precomposed.png" />
<link rel="apple-touch-icon-precomposed" href="<?php echo $URL;?>/app/templeates/Eterna/ico/apple-touch-icon-57-precomposed.png" />
<link rel="shortcut icon" href="<?php echo $URL;?>/app/templeates/Eterna/ico/favicon.png" />

<!-- =======================================================
  Theme Name: Eterna
  Theme URL: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/
  Author: BootstrapMade.com
  Author URL: https://bootstrapmade.com
======================================================= -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca de Arisluz</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #343a40;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        nav h1 {
            color: #fff;
            margin-bottom: 20px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
            transition: color 0.3s ease;
        }
      

nav h1 {
    color: #fff;
    margin-bottom: 20px;
    font-size: 50px; 
  }

  
nav h2 {
    color: #fff;
    margin-bottom: 20px;
    font-size: 36px; 
    font-style: italic;
  }

        nav a:hover {
            color: #ffc107;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav>
            <h1>BIBLIOTECA ITLA</h1>
            <h2>EL SABER ES PODER</h2>
            <a href="index.php">Inicio</a>
            <a href="libro.php">Libros</a>
            <a href="autores.php">Autores</a>
            <a href="Contacto.html">Contacto</a>
        </nav>
    </div>
</body>
</body>
<style>body {
    margin: 0;
    padding: 0;
    background-image: url('public/images/fondo2.jpg'); 
    background-size: cover;
    background-position: center;
    font-family: Arial, sans-serif;
}

.container {
    width: 80%;
    margin: 0 auto; 
    padding: 20px; 
    background-color: rgba(255, 255, 255, 0.8); 
    border-radius: 10px; 
    text-align: center; 
}

.container a {
    display: inline-block;
    margin: 10px;
    padding: 10px 20px;
    background-color: #333; 
    color: #fff; 
    text-decoration: none;
    border-radius: 5px; 
}
</style>


      </div>

    </div>

   